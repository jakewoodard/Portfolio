Overview:
My code reads a list of applicants for MOOGLE and determines
if they are up to their standards. Each applicants grades
are tested 4 times. If they pass all four tests then "ACCEPT" 
is returned, else: "REJECT". Type "python3 main.py" in the 
terminal to execute the program.

Ethical Statement:
I believe this program is ethical enough, but I do not think
it is most effective way to find the best applicants for MOOGLE.
It is a very difficult test to pass for the applicants, the vast
majority were rejected. They are most likely  missing out on some
viable candidates. It should be permissible for real-world use; 
I just wouldn't use it. 
